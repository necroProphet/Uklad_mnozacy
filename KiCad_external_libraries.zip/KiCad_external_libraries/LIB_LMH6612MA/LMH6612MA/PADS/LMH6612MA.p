*PADS-LIBRARY-PART-TYPES-V9*

LMH6612MA SOIC127P600X175-8N I ANA 8 1 0 0 0
TIMESTAMP 2026.11.01.15.18.37
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" LMH6612MA
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Output Amplifiers
"Datasheet Link" 
GATE 1 8 0
LMH6612MA
1 0 U OUT_A
2 0 U -INA
3 0 U +INA
4 0 U V-
5 0 U +INB
6 0 U -INB
7 0 U OUT_B
8 0 U V+

*END*
*REMARK* SamacSys ECAD Model
589671/2207364/2.50/8/0/Integrated Circuit
