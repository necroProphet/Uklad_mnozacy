*PADS-LIBRARY-PART-TYPES-V9*

SH8KC6TB1 SOIC127P600X175-8N I ANA 9 1 0 0 0
TIMESTAMP 2026.10.23.11.29.33
"Manufacturer_Name" ROHM Semiconductor
"Manufacturer_Part_Number" SH8KC6TB1
"Mouser Part Number" 755-SH8KC6TB1
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/ROHM-Semiconductor/SH8KC6TB1?qs=QNEnbhJQKvZOtqarXY16MQ%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" 60V Dual Nch+Nch, SOP8, Power MOSFET
"Datasheet Link" https://fscdn.rohm.com//en/products/databook/datasheet/discrete/transistor/mosfet/sh8kc6tb1-e.pdf
"Geometry.Height" 1.75mm
GATE 1 8 0
SH8KC6TB1
1 0 U TR1_SOURCE
2 0 U TR1_GATE
3 0 U TR2_SOURCE
4 0 U TR2_GATE
8 0 U TR1_DRAIN_2
7 0 U TR1_DRAIN_1
6 0 U TR2_DRAIN_2
5 0 U TR2_DRAIN_1

*END*
*REMARK* SamacSys ECAD Model
16514026/2206547/2.50/8/2/Integrated Circuit
