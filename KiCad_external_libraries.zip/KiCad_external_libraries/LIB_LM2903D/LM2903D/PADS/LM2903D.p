*PADS-LIBRARY-PART-TYPES-V9*

LM2903D SOIC127P600X175-8N I ANA 9 1 0 0 0
TIMESTAMP 2026.11.01.15.18.11
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" LM2903D
"Mouser Part Number" 595-LM2903D
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/LM2903D?qs=3pnr37ZAbK86ajtOsfWBBw%3D%3D
"Arrow Part Number" LM2903D
"Arrow Price/Stock" https://www.arrow.com/en/products/lm2903d/texas-instruments
"Description" LM2903DG4, Dual Comparator Open Collector 1.3s 2-kanalers 3, 5, 9, 12, 15, 18, 24, 28V 8-Pin SOIC
"Datasheet Link" http://www.ti.com/lit/ds/symlink/lm2903.pdf
"Geometry.Height" 1.75mm
GATE 1 8 0
LM2903D
1 0 U 1OUT
2 0 U 1IN-
3 0 U 1IN+
4 0 U GND
8 0 U VCC
7 0 U 2OUT
6 0 U 2IN-
5 0 U 2IN+

*END*
*REMARK* SamacSys ECAD Model
2616/2207364/2.50/8/3/Integrated Circuit
