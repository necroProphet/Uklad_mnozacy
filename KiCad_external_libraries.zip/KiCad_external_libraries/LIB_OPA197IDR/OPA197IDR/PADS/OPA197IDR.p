*PADS-LIBRARY-PART-TYPES-V9*

OPA197IDR SOIC127P600X175-8N I ANA 9 1 0 0 0
TIMESTAMP 2026.11.01.15.20.33
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" OPA197IDR
"Mouser Part Number" 595-OPA197IDR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/OPA197IDR?qs=gMfM3zrbS4ovW9KDi3YhFw%3D%3D
"Arrow Part Number" OPA197IDR
"Arrow Price/Stock" https://www.arrow.com/en/products/opa197idr/texas-instruments?utm_currency=USD&region=europe
"Description" 36-V, Precision, Rail-to-Rail Input Output, Low Offset Voltage Op Amp
"Datasheet Link" http://www.ti.com/lit/gpn/opa197
"Geometry.Height" 1.75mm
GATE 1 8 0
OPA197IDR
1 0 U NC_1
2 0 U -IN
3 0 U +IN
4 0 U V-
8 0 U NC_3
7 0 U V+
6 0 U OUT
5 0 U NC_2

*END*
*REMARK* SamacSys ECAD Model
354426/2207364/2.50/8/3/Integrated Circuit
